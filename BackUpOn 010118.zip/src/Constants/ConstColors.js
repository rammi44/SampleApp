const colors = [{ 'color': '#ff6f00', 'style': { 'backgroundColor': '#ff6f00' } },
{ 'color': '#dd2c00', 'style': { 'backgroundColor': '#dd2c00' } },
{ 'color': '#d50000', 'style': { 'backgroundColor': '#d50000' } },
{ 'color': '#c51162', 'style': { 'backgroundColor': '#c51162' } },
{ 'color': '#9c27b0', 'style': { 'backgroundColor': '#9c27b0' } },
{ 'color': '#6a1b9a', 'style': { 'backgroundColor': '#6a1b9a' } },
{ 'color': '#673ab7', 'style': { 'backgroundColor': '#673ab7' } },
{ 'color': '#311b92', 'style': { 'backgroundColor': '#311b92' } },
{ 'color': '#1976d2', 'style': { 'backgroundColor': '#1976d2' } },
{ 'color': '#00838f', 'style': { 'backgroundColor': '#00838f' } },
{ 'color': '#006064', 'style': { 'backgroundColor': '#006064' } },
{ 'color': '#004d40', 'style': { 'backgroundColor': '#004d40' } },
{ 'color': '#2e7d32', 'style': { 'backgroundColor': '#2e7d32' } },
{ 'color': '#5d4037', 'style': { 'backgroundColor': '#5d4037' } },
{ 'color': '#3e2723', 'style': { 'backgroundColor': '#3e2723' } },
{ 'color': '#424242', 'style': { 'backgroundColor': '#424242' } },
{ 'color': '#455a64', 'style': { 'backgroundColor': '#455a64' } },
{ 'color': '#263238', 'style': { 'backgroundColor': '#263238' } }
]
  
  export default colors;