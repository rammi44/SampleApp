import React, { Component } from 'react';
import { AppRegistry, Text, View, StyleSheet, Alert } from 'react-native';
// import {  Icon } from 'react-native-elements'

import ActionButton from 'react-native-action-button';

import Icon from 'react-native-vector-icons/Ionicons';

// import Icon from 'react-native-vector-icons/SimpleLineIcons';

// import Icon from 'react-native-vector-icons/MaterialIcons';

import { StackNavigator } from 'react-navigation';

import CreateActivity from '../Screens/Create';

class _NextButton extends Component {

    constructor(props) {
        super(props);

        this.setState = {
            buttonText: '',
            buttonColor: '',
            navigation: '',
            NextIcon: ''
        }
    }

    render() {

        // const { navigate } = this.props.navigation;

        // alert(this.props.buttonColor);

        return (

            <View style={styles.actinButnCntManin}>

                {/* Rest of the app comes ABOVE the action button component !*/}

                {/* onPress={() => navigate('CreateActivity', { name: 'Jane' })} */}

                <ActionButton onPress={this.props.onSubmitButton} buttonColor={this.props.buttonColor} buttonText={this.props.NextIcon && <Icon name="md-arrow-forward" style={styles.actionButtonIcon} />}>

                    {/* <ActionButton.Item buttonColor='#9b59b6' title="New Task" onPress={() => console.log("notes tapped!")}>
                        <Icon name="md-create" style={styles.actionButtonIcon} />
                    </ActionButton.Item>

                    <ActionButton.Item buttonColor='#3498db' title="Notifications" onPress={() => { }}>
                        <Icon name="md-notifications-off" style={styles.actionButtonIcon} />
                    </ActionButton.Item>

                    <ActionButton.Item buttonColor='#1abc9c' title="All Tasks" onPress={() => { }}>
                        <Icon name="md-done-all" style={styles.actionButtonIcon} />
                    </ActionButton.Item> */}

                </ActionButton>

            </View>


            // <View style={styles.viewStyles}>

            //     <Icon name="arrow-right-circle" size={30} backgroundColor="red">
            //      </Icon>

            // </View>

        );
    }
};




// export default class TestNextButton extends Component {

//     render() {

//         return (

//             <_NextButton />

//         );
//     }
// };


var styles = StyleSheet.create({

    actinButnCntManin: {
        flex: 1,
    },
    actionButtonIcon: {
        fontSize: 20,
        height: 22,
        color: 'white',
    }
});

export default _NextButton;
// export {_NextButton};
