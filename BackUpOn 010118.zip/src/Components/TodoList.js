import React, { Component } from 'react';
import { View, Text, Alert, StyleSheet, Image, ScrollView, TouchableOpacity, Dimensions, Platform, Easing } from 'react-native';
import AddTodoItem from '../Components/AddTodoItem';
import TodoItems from '../Components/TodoItems';
import Row from '../Components/Row';

import SortableList from 'react-native-sortable-list'; // 0.0.16

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';


const window = Dimensions.get('window');

class _TodoList extends Component {

    constructor(props) {
        super(props);

        this.state = {
            todoItemArray: [{ 'Item': 'Enter To-do Item 1', 'TodoItemstyle': { 'backgroundColor': 'green' } }],
            noteText: '',
            basicOkCancelVisible: false,
            TodoItemstyle: { 'backgroundColor': 'green' },
            isDeleteDefaultItem: false,
        }
    }

    static navigationOptions = ({ navigation }) => ({
        // title: 'Home',	
        header: null,
    });

    render() {

        let notes = this.state.todoItemArray.map((val, key) => {

            return <TodoItems key={key} keyval={key} val={val}
                deleteMethod={() => this.deleteNote(key)} isDeleteVisible={key == 0 ? true : false} />

        });

        // alert(this.props.bgColor);

        // alert(JSON.stringify(this.state.todoItemArray));

        return (

            <View style={styles.mainCnt}>

                <Text style={[styles.btnView, { color: this.props.bgColor }]}>Add Action Items</Text>

                <ScrollView keyboardShouldPersistTaps={'handled'} style={styles.scrollContainer}>
                    {notes}
                    <AddTodoItem basicOkCancelVisible={this.props.basicOkCancelVisible} addTodoItem={(item, todoItembgStyle) => this.addNote(item, todoItembgStyle)} bgColor={this.props.bgColor} />
                </ScrollView>

                {/* <AddTodoItem basicOkCancelVisible={this.props.basicOkCancelVisible} addTodoItem={(item, todoItembgStyle) => this.addNote(item, todoItembgStyle)} bgColor={this.props.bgColor} />

                <SortableList
                    style={styles.list}
                    contentContainerStyle={styles.contentContainer}
                    data={this.state.todoItemArray}
                    renderRow={this._renderRow} /> */}

            </View >

        );
    }


    // _renderRow = ({ key, data, active }) => {
    //     return <Row data={data} active={active} key={key} keyval={key} val={data} deleteMethod={() => this.deleteNote(key)} isDeleteVisible={key == 0 ? true : false} TodoItemstyle />
    // }

    addNote(item, todoItembgStyle) {

        // alert(JSON.stringify(todoItembgStyle));
        // alert(JSON.stringify(item));

        // alert(JSON.stringify(this.state.todoItemArray));

        if (!this.state.isDeleteDefaultItem) {

            this.deleteNote(0);
        }

        if (item) {

            this.state.todoItemArray.push({ 'Item': item, 'TodoItemstyle': todoItembgStyle });

            // this.state.todoItemArray = this._data.concat({ 'Item': item, 'TodoItemstyle': todoItembgStyle });

            // var _ds = JSON.parse(JSON.stringify(this.state.todoItemArray));

            alert(JSON.stringify(this.state.todoItemArray));

            this.setState({
                todoItemArray: this.state.todoItemArray,
                isDeleteDefaultItem: true
            });

            alert('2');

        }
        else {
            alert('Action Can not be empty');
        }
    }

    deleteNote(key) {
        this.state.todoItemArray.splice(key, 1);
        this.setState({ todoItemArray: this.state.todoItemArray });
        this.setState({ noteText: '' });
    }

};

const styles = StyleSheet.create({

    mainCnt: {
        flex: 4,
    },
    scrollContainer: {
        flex: 1,
    },
    btnView: {
        height: 30,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#eee',
        padding: 5, fontWeight: '100'
    },

    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#eee',

        ...Platform.select({
            ios: {
                paddingTop: 20,
            },
        }),
    },

    title: {
        fontSize: 20,
        paddingVertical: 20,
        color: '#999999',
    },

    list: {
        flex: 1,
    },

    contentContainer: {
        width: window.width,

        ...Platform.select({
            ios: {
                paddingHorizontal: 30,
            },

            android: {
                paddingHorizontal: 0,
            }
        })
    },

    row: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#fff',
        padding: 16,
        height: 80,
        flex: 1,
        marginTop: 7,
        marginBottom: 12,
        borderRadius: 4,


        ...Platform.select({
            ios: {
                width: window.width - 30 * 2,
                shadowColor: 'rgba(0,0,0,0.2)',
                shadowOpacity: 1,
                shadowOffset: { height: 2, width: 2 },
                shadowRadius: 2,
            },

            android: {
                width: window.width - 30 * 2,
                elevation: 0,
                marginHorizontal: 30,
            },
        })
    },

    image: {
        width: 50,
        height: 50,
        marginRight: 30,
        borderRadius: 25,
    },

    text: {
        fontSize: 24,
        color: '#222222',
    },

});

export default _TodoList;